﻿namespace E_commerceWebsite.ViewModels
{
    public class AdminDashboardViewModel
    {
    }
}
