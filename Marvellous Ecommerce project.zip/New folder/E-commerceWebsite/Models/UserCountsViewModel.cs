﻿namespace E_commerceWebsite.Models
{
    public class UserCountsViewModel
    {
        public int ActiveUsers { get; set; }
        public int InactiveUsers { get; set; }
        public int Admins { get; set; }
    }
}
