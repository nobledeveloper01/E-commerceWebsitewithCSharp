﻿namespace E_commerceWebsite.Data
{
    public class DbInitializer
    {
    }
}
